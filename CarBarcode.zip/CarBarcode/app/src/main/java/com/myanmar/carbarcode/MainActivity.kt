package com.myanmar.carbarcode

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var etPlateNumber: EditText
    private lateinit var etChassisNumber: EditText
    private lateinit var etExpiryDate: EditText
    private lateinit var tvDateError: TextView
    private lateinit var btnGenerate: Button
    private lateinit var cardBarcode: CardView
    private lateinit var ivBarcode: ImageView
    private lateinit var tvBarcodeInfo: TextView
    private lateinit var btnSave: Button
    private lateinit var btnShare: Button

    private var currentBitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etPlateNumber = findViewById(R.id.etPlateNumber)
        etChassisNumber = findViewById(R.id.etChassisNumber)
        etExpiryDate = findViewById(R.id.etExpiryDate)
        tvDateError = findViewById(R.id.tvDateError)
        btnGenerate = findViewById(R.id.btnGenerate)
        cardBarcode = findViewById(R.id.cardBarcode)
        ivBarcode = findViewById(R.id.ivBarcode)
        tvBarcodeInfo = findViewById(R.id.tvBarcodeInfo)
        btnSave = findViewById(R.id.btnSave)
        btnShare = findViewById(R.id.btnShare)

        // Auto format date input as dd/MM/yyyy
        etExpiryDate.addTextChangedListener(object : TextWatcher {
            var isFormatting = false
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (isFormatting) return
                isFormatting = true
                val digits = s.toString().filter { it.isDigit() }
                val formatted = when {
                    digits.length <= 2 -> digits
                    digits.length <= 4 -> "${digits.substring(0,2)}/${digits.substring(2)}"
                    else -> "${digits.substring(0,2)}/${digits.substring(2,4)}/${digits.substring(4, minOf(digits.length, 8))}"
                }
                etExpiryDate.setText(formatted)
                etExpiryDate.setSelection(formatted.length)
                isFormatting = false
                validateDate(formatted)
            }
        })

        btnGenerate.setOnClickListener { generateBarcode() }
        btnSave.setOnClickListener { saveBarcode() }
        btnShare.setOnClickListener { shareBarcode() }
    }

    private fun validateDate(date: String): Boolean {
        if (date.length < 10) {
            tvDateError.visibility = View.GONE
            return false
        }
        return try {
            val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            sdf.isLenient = false
            sdf.parse(date)
            tvDateError.visibility = View.GONE
            true
        } catch (e: Exception) {
            tvDateError.text = "❌ ရက်စွဲ မှားနေသည် (dd/MM/yyyy ဖြည့်ပါ)"
            tvDateError.visibility = View.VISIBLE
            false
        }
    }

    private fun generateBarcode() {
        val plate = etPlateNumber.text.toString().trim().uppercase()
        val chassis = etChassisNumber.text.toString().trim().uppercase()
        val expiry = etExpiryDate.text.toString().trim()

        if (plate.isEmpty()) {
            etPlateNumber.error = "ကားနံပတ် ဖြည့်ပါ"
            etPlateNumber.requestFocus()
            return
        }
        if (chassis.isEmpty()) {
            etChassisNumber.error = "ချက်စီနံပတ် ဖြည့်ပါ"
            etChassisNumber.requestFocus()
            return
        }
        if (!validateDate(expiry)) {
            etExpiryDate.requestFocus()
            return
        }

        // Build barcode data string
        val barcodeData = "$plate$chassis$expiry"

        try {
            val hints = mapOf(
                EncodeHintType.ERROR_CORRECTION to com.google.zxing.pdf417.encoder.Compaction.AUTO,
                EncodeHintType.MARGIN to 2
            )
            val writer = MultiFormatWriter()
            val bitMatrix = writer.encode(barcodeData, BarcodeFormat.PDF_417, 900, 300, null)

            val width = bitMatrix.width
            val height = bitMatrix.height
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

            for (x in 0 until width) {
                for (y in 0 until height) {
                    bitmap.setPixel(x, y, if (bitMatrix[x, y]) Color.BLACK else Color.WHITE)
                }
            }

            currentBitmap = bitmap
            ivBarcode.setImageBitmap(bitmap)
            tvBarcodeInfo.text = "ကားနံပတ်: $plate  •  ချက်စီ: $chassis  •  ကုန်ဆုံးရက်: $expiry"
            cardBarcode.visibility = View.VISIBLE

            // Scroll to barcode
            cardBarcode.post {
                (cardBarcode.parent as? View)?.scrollTo(0, cardBarcode.top)
            }

        } catch (e: Exception) {
            Toast.makeText(this, "Barcode ထုတ်မရပါ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveBarcode() {
        val bitmap = currentBitmap ?: return
        val plate = etPlateNumber.text.toString().trim().uppercase().replace("/", "-")
        val filename = "barcode_${plate}_${System.currentTimeMillis()}.png"

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+ — save to MediaStore
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/CarBarcode")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                uri?.let {
                    contentResolver.openOutputStream(it)?.use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                    Toast.makeText(this, "✅ Pictures/CarBarcode မှာ သိမ်းပြီးပြီ", Toast.LENGTH_LONG).show()
                }
            } else {
                // Android 9 and below
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this,
                        arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 100)
                    return
                }
                val dir = File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_PICTURES), "CarBarcode")
                dir.mkdirs()
                val file = File(dir, filename)
                FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                Toast.makeText(this, "✅ Pictures/CarBarcode မှာ သိမ်းပြီးပြီ", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "သိမ်းမရပါ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareBarcode() {
        val bitmap = currentBitmap ?: return
        val plate = etPlateNumber.text.toString().trim().uppercase().replace("/", "-")

        try {
            val cacheDir = File(cacheDir, "barcodes")
            cacheDir.mkdirs()
            val file = File(cacheDir, "barcode_$plate.png")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }

            val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "ကားနံပတ် $plate ၏ PDF417 Barcode")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Barcode မျှဝေမည်"))
        } catch (e: Exception) {
            Toast.makeText(this, "မျှဝေမရပါ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
