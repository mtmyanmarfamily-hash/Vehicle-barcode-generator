App: Myanmar Car Barcode Generator
Package: com.myanmar.carbarcode
Features:
- Input: Plate Number, Chassis Number, License Expiry Date (DD/MM/YYYY)
- Generate PDF417 barcode
- Save to gallery
- Myanmar + English UI
Library: com.google.zxing:core:3.5.2 for PDF417
